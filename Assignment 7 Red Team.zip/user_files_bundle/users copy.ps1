# users.ps1

Set-StrictMode -Version Latest

function New-StealthUser {
    param(
        [string]$Name,
        [string]$Role = "Student",
        [int]$ClearanceLevel = 1,
        [int]$LoginAttempts = 1,
        [datetime]$LastLogin = (Get-Date).AddDays(-1),
        [string[]]$AccessLog = @()
    )

    # Build the hashtable (user record)
    $user = @{
        Name = $Name
        Role = $Role
        ClearanceLevel = $ClearanceLevel
        LoginAttempts = $LoginAttempts
        LastLogin = $LastLogin
        AccessLog = ,$AccessLog
    }
    return $user
}

function Get-UserThreatClassification {
    param([hashtable]$User)

    # Default classification
    $classification = "Normal"

    # Conditions indicating stealthy threat:
    
    $highRiskActions = "accessadmin_panel","modify_users","delete_records","export_db","impersonate_user","change_roles"

    $hasHighRisk = ($User.AccessLog | Where-Object { $highRiskActions -contains $_ }).Count -gt 0
    $roleMismatch = ($User.Role -in @("Student","Guest")) -and ($User.AccessLog | Where-Object { $_ -match "admin" -or $_ -match "manage" -or $_ -match "modify" }).Count -gt 0
    $recentAndSuspicious = ($User.LastLogin -gt (Get-Date).AddDays(-7)) -and $hasHighRisk
    $obviousThreat = $User.LoginAttempts -gt 5 -or ($User.AccessLog -contains "bruteforce_tool_detected") -or ($User.LoginAttempts -gt 3 -and $hasHighRisk)

    if ($roleMismatch -or ($hasHighRisk -and $User.LoginAttempts -le 2 -and $User.ClearanceLevel -lt 3) -or $recentAndSuspicious) {
        $classification = "Stealth Threat"
    } elseif ($obviousThreat) {
        $classification = "Obvious Threat"
    } else {
        $classification = "Normal"
    }

    # Add classification to user record 
    $u = $User.Clone()
    $u.Add("Classification", $classification)
    return $u
}

# Generate dataset
$Users = @()

# Normal users
$Users += New-StealthUser -Name "Zara" -Role "Student" -ClearanceLevel 2 -LoginAttempts 1 -LastLogin (Get-Date).AddDays(-1) -AccessLog @("viewgrades","viewassignments")
$Users += New-StealthUser -Name "ProfMiller" -Role "Faculty" -ClearanceLevel 4 -LoginAttempts 2 -LastLogin (Get-Date).AddDays(-2) -AccessLog @("grade_submissions","viewgrades")
$Users += New-StealthUser -Name "IT_Sam" -Role "Admin" -ClearanceLevel 5 -LoginAttempts 1 -LastLogin (Get-Date).AddDays(-10) -AccessLog @("manage_servers","apply_patches")

# Stealth threats
# 1) Low login attempts but accessed admin panel recently (role mismatch)
$Users += New-StealthUser -Name "Liam" -Role "Student" -ClearanceLevel 1 -LoginAttempts 1 -LastLogin (Get-Date).AddDays(-2) -AccessLog @("viewgrades","accessadmin_panel")

# 2) Low attempts, high-risk action (export_db) with recent login
$Users += New-StealthUser -Name "Ava" -Role "Guest" -ClearanceLevel 1 -LoginAttempts 2 -LastLogin (Get-Date).AddHours(-20) -AccessLog @("viewpublic","export_db")

# 3) Student with modify_users action but only 1 login attempt (very stealthy)
$Users += New-StealthUser -Name "Noah" -Role "Student" -ClearanceLevel 1 -LoginAttempts 1 -LastLogin (Get-Date).AddDays(-3) -AccessLog @("viewgrades","modify_users")

# Obvious threats
$Users += New-StealthUser -Name "BadBot" -Role "Guest" -ClearanceLevel 0 -LoginAttempts 12 -LastLogin (Get-Date).AddMinutes(-30) -AccessLog @("login_attempt","bruteforce_tool_detected","failed_login")
$Users += New-StealthUser -Name "Eve" -Role "Student" -ClearanceLevel 2 -LoginAttempts 4 -LastLogin (Get-Date).AddDays(-40) -AccessLog @("viewgrades","suspicious_download","viewprivate_forum")
$Users += New-StealthUser -Name "Maya" -Role "Faculty" -ClearanceLevel 3 -LoginAttempts 2 -LastLogin (Get-Date).AddDays(-31) -AccessLog @("grade_submissions","bulk_export")
$Users += New-StealthUser -Name "Oliver" -Role "Student" -ClearanceLevel 1 -LoginAttempts 1 -LastLogin (Get-Date).AddDays(-60) -AccessLog @("viewgrades")

# Ensure at least 8 users
# Classify each user
$ClassifiedUsers = $Users | ForEach-Object { Get-UserThreatClassification -User $_ }

# Pipeline: extract stealth threats
$StealthThreats = $ClassifiedUsers | Where-Object { $_.Classification -eq "Stealth Threat" }

# Report generator
function Write-RedTeamReport {
    param(
        [array]$AllUsers,
        [array]$StealthUsers,
        [string]$OutputPath = "RedTeamReport.txt"
    )

    $lines = @()
    $lines += "Red Team Report"
    $lines += ("Generated: {0}" -f (Get-Date))
    $lines += ""
    $lines += ("Total users created: {0}" -f $AllUsers.Count)
    $lines += ("Number of stealth threats: {0}" -f $StealthUsers.Count)
    $lines += ""

    $lines += "Detailed user classification and stealth design notes:"
    foreach ($u in $AllUsers) {
        $uSummary = ("- {0} | Role: {1} | Clearance: {2} | Logins: {3} | LastLogin: {4} | Classification: {5}" -f `
            $u.Name, $u.Role, $u.ClearanceLevel, $u.LoginAttempts, $u.LastLogin, $u.Classification)
        $lines += $uSummary

        if ($u.Classification -eq "Stealth Threat") {
            # Explain how this threat is designed to bypass detection
            $reasons = @()
            if ($u.LoginAttempts -le 2) { $reasons += "Low login attempts (avoids threshold-based alerts)" }
            if (($u.AccessLog | Where-Object { $_ -match "admin|modify|export|impersonate|delete" }).Count -gt 0) { $reasons += "Performed high-risk action(s): $($u.AccessLog -join ', ')" }
            if (($u.Role -in @("Student","Guest")) -and ($u.AccessLog | Where-Object { $_ -match "admin|manage|modify" }).Count -gt 0) { $reasons += "Role mismatch (non-privileged role accessing privileged actions)" }
            if ($u.LastLogin -gt (Get-Date).AddDays(-7)) { $reasons += "Recent login (within 7 days) combined with risky actions" }
            if ($reasons.Count -eq 0) { $reasons += "Stealth pattern detected by heuristics." }

            $lines += ("  -> How it bypasses detection: {0}" -f ($reasons -join '; '))
        }
    }

    $lines += ""
    $lines += "Stealth threats (pipeline extracted):"
    foreach ($s in $StealthUsers) {
        $lines += ("- {0} : Actions => {1}" -f $s.Name, ($s.AccessLog -join ', '))
    }

    # Output to file
    $lines | Out-File -FilePath $OutputPath 

    return $OutputPath
}

# Generate report file
$reportPath = Write-RedTeamReport -AllUsers $ClassifiedUsers -StealthUsers $StealthThreats -OutputPath "RedTeamReport.txt"

Write-Host "Red Team dataset generated. Classified users saved in memory. Report written to $reportPath."
# Optionally export the dataset to a JSON for Blue Team ingestion
$ClassifiedUsers | ConvertTo-Json -Depth 5 | Out-File -FilePath "users_dataset.json" 
Write-Host "users_dataset.json written for Blue Team ingestion."
